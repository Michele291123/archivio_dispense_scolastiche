#!/usr/bin/env node

let raw = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { raw += chunk; });
process.stdin.on('end', () => {
  let input = {};
  try { input = JSON.parse(raw); } catch (_) {}

  const c = (code, text) => `\x1b[${code}m${text}\x1b[0m`;
  const cyan   = t => c('38;5;45',  t);
  const yellow = t => c('38;5;226', t);
  const orange = t => c('38;5;214', t);
  const grey   = t => c('38;5;240', t);
  const green  = t => c('38;5;82',  t);
  const red    = t => c('38;5;196', t);

  function bar(pct, size = 6) {
    if (pct == null) return grey('?' .repeat(size));
    const p = Math.max(0, Math.min(100, Math.round(pct)));
    const filled = Math.round(p / 100 * size);
    const empty  = size - filled;
    const color  = p >= 80 ? red : p >= 50 ? orange : green;
    return color('█'.repeat(filled)) + grey('░'.repeat(empty));
  }

  function resetIn(ts) {
    if (!ts) return '';
    const mins = Math.round((ts * 1000 - Date.now()) / 60000);
    if (mins <= 0) return grey(' (ora)');
    if (mins < 60) return grey(` (${mins}m)`);
    return grey(` (${Math.round(mins / 60)}h)`);
  }

  const parts = [];

  // Model
  const model = (input.model && (input.model.display_name || input.model.id)) || '';
  if (model) parts.push(cyan(model));

  // Context window
  const ctx = input.context_window || {};
  let ctxPct = ctx.used_percentage ?? null;
  if (ctxPct == null && ctx.total_input_tokens && ctx.context_window_size > 0)
    ctxPct = Math.round(ctx.total_input_tokens / ctx.context_window_size * 100);

  const ctxLabel = grey('Ctx:');
  const ctxBar   = bar(ctxPct);
  const ctxNum   = ctxPct != null ? orange(`${Math.round(ctxPct)}%`) : grey('–');
  parts.push(`${ctxLabel} ${ctxBar} ${ctxNum}`);

  // Rate limits
  const rl = input.rate_limits || {};

  if (rl.five_hour) {
    const pct = rl.five_hour.used_percentage ?? null;
    const label = grey('Sessione:');
    const num   = pct != null ? orange(`${Math.round(pct)}%`) : grey('–');
    parts.push(`${label} ${bar(pct)}${resetIn(rl.five_hour.resets_at)} ${num}`);
  }

  if (rl.seven_day) {
    const pct = rl.seven_day.used_percentage ?? null;
    const label = grey('Settimana:');
    const num   = pct != null ? orange(`${Math.round(pct)}%`) : grey('–');
    parts.push(`${label} ${bar(pct)}${resetIn(rl.seven_day.resets_at)} ${num}`);
  }

  process.stdout.write(parts.join('  '));
});
