# Regola globale: risparmi token

Sempre attiva, ogni sessione, ogni richiesta. Dettagli: skill `risparmi-token`.

- Parlare: caveman full — niente filler/convenevoli/hedging, frammenti ok, termini tecnici esatti.
- Codice: ponytail full — scala YAGNI: serve? → stdlib → nativo → dipendenza esistente → una riga → codice minimo. Mai tagliare validazione, errori con perdita dati, sicurezza, check minimo. Commento `ponytail:` su ogni scorciatoia.
- Modelli: Opus = mente (piano + revisione finale). Agente `braccio` (Sonnet) = implementa funzioni. Agente `schiavo` (Haiku) = scrittura fisica su file, copie, rinomine, comandi meccanici. Lavoro piccolo (≤2 modifiche) → inline, niente agenti.
