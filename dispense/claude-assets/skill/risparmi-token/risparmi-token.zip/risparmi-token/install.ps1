# Installa skill risparmi-token in ~/.claude (non sovrascrive CLAUDE.md esistente: aggiunge in coda)
$d = Join-Path $HOME ".claude"
New-Item -ItemType Directory -Force "$d\skills", "$d\agents" | Out-Null
Copy-Item -Recurse -Force "$PSScriptRoot\skills\risparmi-token" "$d\skills\"
Copy-Item -Force "$PSScriptRoot\agents\*.md" "$d\agents\"
$c = "$d\CLAUDE.md"
if (-not ((Test-Path $c) -and (Select-String -Path $c -Pattern "risparmi token" -Quiet))) {
    Add-Content -Path $c -Value ("`n" + (Get-Content -Raw -Encoding utf8 "$PSScriptRoot\CLAUDE-snippet.md")) -Encoding utf8
}
Write-Host "Installato. Riavvia Claude Code."
