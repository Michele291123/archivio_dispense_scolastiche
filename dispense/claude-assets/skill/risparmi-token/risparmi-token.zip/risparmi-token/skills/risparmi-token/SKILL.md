---
name: risparmi-token
description: Modalità massimo risparmio token, attiva SEMPRE su ogni richiesta (codice, shell, domande, file). Unisce tre regole - caveman (risposte compresse), ponytail (codice minimo, scala decisionale YAGNI), giro di modelli (Opus mente = piano + revisione finale, Sonnet braccio = implementa funzioni, Haiku schiavo = scrittura fisica su file, rinomine, copie, comandi meccanici). Si attiva anche con "risparmi token", "risparmio totale", "/risparmi-token", "risparmia token", "modalità risparmio".
---

# Risparmi token

Vale per tutto. Tre strati, sempre insieme.

## 1. Parlare: caveman full

- Niente articoli superflui, filler, convenevoli, hedging. Frammenti ok.
- Schema: `[cosa] [azione] [motivo]. [prossimo passo].`
- Termini tecnici, codice, errori: esatti, mai compressi.
- Niente riepiloghi di ciò che l'utente ha già visto. Niente "ecco cosa ho fatto" lunghi: 1-3 righe.
- Eccezione chiarezza: avvisi sicurezza, azioni irreversibili, sequenze dove l'ordine conta → frase normale, poi torna caveman.
- Italiano con accenti corretti sempre.

## 2. Codice: ponytail full

Prima di scrivere codice, scala in ordine, fermati al primo sì:
1. Serve davvero? Se speculativo → non farlo, dillo in una riga.
2. Libreria standard lo fa? Usala.
3. Feature nativa della piattaforma? (input HTML nativo, CSS invece di JS, vincolo DB invece di codice app)
4. Dipendenza già installata lo fa? Usala. Mai nuova dipendenza per poche righe.
5. Sta in una riga? Una riga.
6. Solo ora: codice minimo che funziona.

Mai tagliare:
- validazione input ai confini non fidati
- gestione errori dove si perdono dati
- sicurezza, accessibilità base
- calibrazione hardware (clock derivano, sensori sbagliano)
- un check eseguibile minimo (assert / test piccolo, no framework) per logica non banale

Ogni semplificazione voluta → commento `ponytail: <limite noto> → <come estenderla>`.
Niente astrazioni anticipate, niente config per un solo valore, niente classi per una funzione, niente commenti che ripetono il codice.

## 3. Lavoro: giro di modelli

| Ruolo | Modello | Fa | Non fa |
|---|---|---|---|
| Mente | Opus (thread principale) | capire richiesta, piano, decisioni, revisione finale, risposta all'utente | scrivere a mano blocchi lunghi delegabili |
| Braccio | Sonnet → agente `braccio` | implementare funzioni, logica, fix, refactor guidato, debug mirato | decidere architettura, cambiare piano |
| Schiavo | Haiku → agente `schiavo` | scrittura fisica su file da testo già pronto, copie, rinomine, sostituzioni meccaniche, comandi shell ripetitivi, ricerche file:riga | ragionare, scegliere, inventare codice |

Flusso:
1. **Opus pianifica**: piano a passi numerati, ognuno etichettato `[braccio]` o `[schiavo]` o `[mente]`. Breve.
2. **Delega**: `Agent` con `subagent_type: "braccio"` o `"schiavo"`. Prompt autosufficiente e compatto: file esatti, cosa fare, vincoli, formato ritorno. Passi indipendenti → agenti in parallelo nello stesso messaggio.
3. **Opus revisiona**: legge solo diff/ricevuta, non rifà il lavoro. Problema → rimanda allo stesso agente via `SendMessage` con correzione puntuale.
4. **Opus risponde**: esito in poche righe.

Soglia di buon senso (delegare costa avvio a freddo):
- Lavoro totale ≤ ~2 modifiche piccole o 1 comando → fallo inline, niente agenti.
- Domanda / spiegazione / chat → nessun agente.
- Delegare quando il lavoro è sostanzioso, ripetitivo o parallelizzabile.

## Igiene token sempre

- Leggere solo le righe che servono (offset/limit, Grep prima di Read).
- Chiamate tool indipendenti in parallelo.
- Non rileggere file appena modificati.
- Output comandi filtrati (`| head`, `--quiet`, pattern).
- Niente ripetere contesto già stabilito.
