# risparmi-token

Skill Claude Code: caveman (risposte compresse) + ponytail (codice minimo) + giro di modelli
(Opus mente, Sonnet `braccio`, Haiku `schiavo`).

## Installazione
Windows: tasto destro su `install.ps1` → Esegui con PowerShell
(oppure `powershell -ExecutionPolicy Bypass -File install.ps1`). Poi riavvia Claude Code.

Manuale:
- `skills/risparmi-token` → `~/.claude/skills/`
- `agents/*.md` → `~/.claude/agents/`
- contenuto di `CLAUDE-snippet.md` → in coda a `~/.claude/CLAUDE.md` (lo rende sempre attivo)

Consigliato: modello principale Opus (`/model opus`).
